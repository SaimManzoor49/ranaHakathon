import './App.scss';
import 'bootstrap/dist/js/bootstrap.bundle';
import Routes from './pages/Routes';
function App() {
  return (
<>

<Routes/>

</>
  );
}

export default App;
