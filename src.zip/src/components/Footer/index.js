import React from 'react'
import Footer from './Footer'
import FooterB from './FooterB'

export default function index() {
  return (
    <>
     <Footer />
     <FooterB /> 
    </>
  )
}
