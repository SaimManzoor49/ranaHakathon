import React from 'react'
import Header from './Header'

export default function index() {
  return (
    <>
    <Header />
    </>
  )
}
