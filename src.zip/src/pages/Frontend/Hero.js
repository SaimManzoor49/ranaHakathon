import React from 'react'

export default function Hero() {
  return (
    <>
    <div className="container-fluid">
        <div className="row">
            <div className="col-12 col-md-5 p-0">

<img src="" alt="" />
            </div>
            <div className="col-12 col-md-7 p-0">

<img src="" alt="" />
            </div>

        </div>
    </div>
    
    
    </>
  )
}
