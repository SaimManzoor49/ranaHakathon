import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Frontend from './Frontend';
import Header from '../components/Header';
import Footer from '../components/Footer';
export default function CustomRoutes() {
  return (
    <div>
 <BrowserRouter>
 <Header/>
 <main>
 <Routes>
<Route path='/*' element={<Frontend/>} />



 </Routes>
 </main>
 <Footer/>
 </BrowserRouter>     

</div>
  )
}
